import socketserver
import socket
import os
import threading
import math
## Python 3.7

# Direccion y puerto local
host = "localhost"
# Puerto division, potenciacion, logaritmacion
lsPuerto = [9996, 9995, 9994] 

# #----------------------------SERVIDOR--------------------------------------

# Clase socket servidor	Resta
class miHandler(socketserver.BaseRequestHandler):

	def handle(self):

		# Recibe 2 numeros, de a 1024 datos
		self.numeros = str(self.request.recv(1024).decode("UTF-8"))
		print("los numeros recibidos son: ", self.numeros)

		# Convertimos a lista
		self.listaNum = self.numeros.split()
		# Convertimos a enteros para operar
		self.ope = (self.listaNum[0])		
		
		if self.ope == "6":
			self.num1 = int(self.listaNum[1])
			self.num2 = int(self.listaNum[2])

			# Llamamos la funcion resta y Convertimos a String el resultado de la logaritmo
			self.logaritmo = str(loga(self.num1, self.num2))
			print("La Logaritmacion es =", self.logaritmo)

			# Enviamos el resultado
			self.request.send(self.logaritmo.encode("UTF-8"))

#Creando hilo para servidor
class serverThread(threading.Thread):
	def __init__(self):
		threading.Thread.__init__(self)

	def run(self):
		print("\n\t\tTaller 5 \nservidor intermedio listado dinámico descentralizado\n")
		print("\n\t Servidor Multiplicacion escuchando...\n")
		host2 = "localhost"

		# Llamamos la clase socket servidor con los parametros de direccion y puerto
		server1 = socketserver.TCPServer((host2, lsPuerto[2]), miHandler)
		# Mantenemos al servidor en estado de escucha
		server1.serve_forever()

hiloServer = serverThread()
hiloServer.start()

continuar = (input("\nPresione enter para continuar. ->"))
print("\n\t Cliente logaritmacion escuchando...\n")

#----------------------------CLIENTE--------------------------------------		

def menu():
   print("___________________________________________________")
   print("\t\t*MENU DE OPERACIONES*")
   print("1. SUMA")
   print("2. RESTA")
   print("3. MULTIPLICACION")
   print("4. DIVISION")
   print("5. POTENCIACION")
   print("6. LOGARITMACION")
   print("0. PARA SALIR")

# Funcion que recibe los datos digitados
def digitarNumero():
   x = (input("ingrese el primer numero: "))
   y = (input("Ingrese el segundo numero: "))

   return x, y

def loga(numero1, numero2):
	return math.log(int(numero1), int(numero2))

def conexionSerFinal(n1, n2, op, nh, np): #nh nuevo host, np nuevo puerto
	# Creamos el socket
	socket1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

	# Conectamos con el servidor
	socket1.connect((nh, np))

	listaN = []
	# Agregamos a lista
	listaN.append(op)
	listaN.append(n1)
	listaN.append(n2)	
	# Convertimos de lista a string
	listaStringN = ' '.join(listaN)

	# Enviamos los 2 valores a operar al servidor 
	socket1.send(listaStringN.encode("UTF-8"))
	# Recibimos el resultado del servidor
	res = str(socket1.recv(1024).decode("UTF-8"))
	socket1.close()

	return res  

def conexionSerInter(op, nh, np):
	socket2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

	# Establecemos conexion con servidor intermedio
	socket2.connect((nh, np))

	# Enviamos el socket con los datos de operacion a servidor intermedio
	socket2.send(op.encode("UTF-8"))
	# Recibimos la direccion del servidor multi del servidor intermedio
	dirServidor = socket2.recv(1024).decode("UTF-8")

	# Convertimos a lista
	listaDir = dirServidor.split()
	host1 = host
	# Convertimos el puerto a entero
	puerto1 = int(listaDir[0])
	print(puerto1)
	socket2.close()

	return host1, puerto1 

# Principal
class serverThread2(threading.Thread):
	def __init__(self):
		threading.Thread.__init__(self)

	def run(self):
		menu()
		while True:
			opcion = (input("Digite la operacion a realizar: "))
						
			if opcion == "1":
				# Llamamos la funcion que nos enterga los numeros digitados
				numero1, numero2 = digitarNumero()
				lsPuert = 9999
				lsPuerto.append(lsPuert)

				# Llamamos la funcion suma
				resultadoSuma = conexionSerFinal(numero1, numero2, opcion, host, lsPuerto[3])
				print("\nNumero 1 = "+ numero1 + ", Numero 2 = " + numero2 + ", Operacion = ", opcion)
				print("\nEl resultado de la suma es =", resultadoSuma)
				print("\n")				

			elif opcion == "2":
				# Llamamos la funcion que nos enterga los numeros digitados
				numero1, numero2 = digitarNumero()

				print("\nEl servidor solicitado no encuentra la opcion...\nBuscando nuevo servidor...")
				# Llamamos la funcion conexion con Servidor Intermedio
				nuevoHost, nuevoPuerto = conexionSerInter(opcion, host, lsPuerto[0])
				print("\nLa direccion del servidor resta es: ", nuevoHost, nuevoPuerto)

				# Llamamos la funcion conexion con Servidor Final
				resultadoResta = conexionSerFinal(numero1, numero2, opcion, nuevoHost, nuevoPuerto)
				print("\nNumero 1 = "+ numero1 + ", Numero 2 = " + numero2 + ", Operacion = ", opcion)
				print("\nEl resultado de la resta es =", resultadoResta)
				print("\n")	

			elif opcion == "3": 
                # Llamamos la funcion que nos enterga los numeros digitados
				numero1, numero2 = digitarNumero()
				print("\nEl servidor solicitado no encuentra la opcion...\nBuscando nuevo servidor...")
				# Llamamos la funcion conexion con Servidor Intermedio
				nuevoHost, nuevoPuerto = conexionSerInter(opcion, host, lsPuerto[0])
				print("\nLa direccion del servidor division es: ", nuevoHost, nuevoPuerto)

				# Llamamos la funcion conexion con Servidor Final
				resultadoMulti = conexionSerFinal(numero1, numero2, opcion, nuevoHost, nuevoPuerto)
				print("\nNumero 1 = "+ numero1 + ", Numero 2 = " + numero2 + ", Operacion = ", opcion)
				print("\nEl resultado de la multiplicacion es =", resultadoMulti)
				print("\n")

			elif opcion == "4":
				# Llamamos la funcion que nos enterga los numeros digitados
				numero1, numero2 = digitarNumero()

				# Llamamos la funcion suma
				resultadoDivi = conexionSerFinal(numero1, numero2, opcion, host, lsPuerto[0])
				print("\nNumero 1 = "+ numero1 + ", Numero 2 = " + numero2 + ", Operacion = ", opcion)
				print("\nEl resultado de la division es =", resultadoDivi)

				print("\n Que tengas un buen dia, si deseas realizar otra operacion ejecute de nuevo el cliente. ")
			
			elif opcion == "5":
				# Llamamos la funcion que nos entrega los numeros digitados
				numero1, numero2 = digitarNumero()

				# Llamamos la funcion suma
				resultadoPot = conexionSerFinal(numero1, numero2, opcion, host, lsPuerto[1])
				print("\nNumero 1 = "+ numero1 + ", Numero 2 = " + numero2 + ", Operacion = ", opcion)
				print("\nEl resultado de la potencia es =", resultadoPot)

				print("\n Que tengas un buen dia, si deseas realizar otra operacion ejecute de nuevo el cliente. ")			
           		
			elif opcion == "6":
				# Llamamos la funcion que nos enterga los numeros digitados
				numero1, numero2 = digitarNumero()

				# Llamamos la funcion suma
				resultadoLog = loga(numero1, numero2)
				print("\nNumero 1 = "+ numero1 + ", Numero 2 = " + numero2 + ", Operacion = ", opcion)
				print("\nEl resultado del logaritmo es =", resultadoLog)

				print("\n Que tengas un buen dia, si deseas realizar otra operacion ejecute de nuevo el cliente. ")	

			elif opcion == "0":
				print("El programa se ha cerrado... Ejecuta el cliente para comenzar de nuevo.")	
				break						
            
hiloCliente = serverThread2()
hiloCliente.start()